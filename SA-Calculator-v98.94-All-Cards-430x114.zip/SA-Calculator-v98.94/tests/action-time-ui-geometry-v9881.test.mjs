import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const css=fs.readFileSync(path.join(root,'assets/css/tool-reference-ui.css'),'utf8');
const html=fs.readFileSync(path.join(root,'index.html'),'utf8');
const js=fs.readFileSync(path.join(root,'assets/js/app.js'),'utf8');

test('v98.81 keypad uses the reference large four-row action-time geometry',()=>{
  assert.match(css,/--tool-keypad-height:500px/);
  assert.match(css,/body\.tool-screen-active #tool-keypad-dock\s*\{[\s\S]*height:var\(--tool-keypad-height\)/);
  assert.match(css,/grid-template-rows:repeat\(4,minmax\(0,1fr\)\)/);
  assert.match(css,/grid-column:4 !important;\s*grid-row:3 \/ span 2/);
});


test('v98.81 clean reset locks reference 720x1560 GST geometry and removes the old override tail',()=>{
  assert.match(css,/reference-screen-toolbar[\s\S]*flex:0 0 104px/);
  assert.match(css,/calc-scrollable[\s\S]*padding:0 20px 16px/);
  assert.match(css,/gst-reference-card[\s\S]*min-height:145px[\s\S]*height:145px/);
  assert.match(css,/gst-amount-field > \.input-val-box[\s\S]*font-size:34px/);
  assert.match(css,/gst-result-card[\s\S]*margin:40px 0 0/);
  assert.match(css,/gst-video-result-row[\s\S]*min-height:39px[\s\S]*font-size:23px/);
  assert.doesNotMatch(css,/v98\.80 exact action-time cleanup/);
});

 test('v98.81 action-time scroll paths are non-animated to avoid touch race conditions',()=>{
  assert.match(js,/scroller\.scrollBy\(\{ top: rect\.bottom - keypadTop \+ 24, behavior: 'auto' \}\)/);
  assert.match(js,/scroller\.scrollBy\(\{ top: lowestBottom - safeBottom \+ 8, behavior: 'auto' \}\)/);
  assert.match(js,/result\.scrollIntoView\(\{ block: 'nearest', behavior: 'auto' \}\)/);
});

test('v98.81 GST field layout prevents nested rate-field overlap',()=>{
  assert.match(css,/#screen-salestax \.gst-rate-card\s*\{[\s\S]*grid-template-columns:minmax\(0,1fr\) auto/);
  assert.match(css,/#screen-salestax \.gst-rate-field \.reference-input-suffix\s*\{[\s\S]*grid-column:2/);
  assert.match(css,/#screen-salestax \.gst-choice-row\s*\{[\s\S]*align-items:center/);
  assert.match(css,/reference-screen-toolbar[\s\S]*flex:0 0 104px/);
  assert.match(css,/gst-reference-card[\s\S]*min-height:145px/);
});

test('v98.81 SIP inactive tab remains readable',()=>{
  assert.match(css,/#screen-sip \.sip-video-tabs button\s*\{[\s\S]*color:#55565a/);
  assert.match(css,/#screen-sip \.sip-video-tabs button\.active[\s\S]*color:#fff/);
});

test('v98.81 saving period unit cannot escape its field',()=>{
  assert.match(css,/#screen-savings \.savings-field:has\(#sav-m\) \.savings-period-unit[\s\S]*white-space:nowrap/);
});

test('v98.81 starts currency pair from a fresh v2 storage namespace',()=>{
  assert.match(js,/CURRENCY_PAIR_STORAGE_KEY\s*=\s*'sa_currency_selected_pair_v2'/);
  assert.match(js,/return \{ from: 'USD', to: 'INR' \}/);
  assert.match(html,/id="cur-from"/);
  assert.match(html,/id="cur-to"/);
});
