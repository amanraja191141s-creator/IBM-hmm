# SA Calculator v98.91

- Repositioned `GST Rate(%)` to the upper marked line.
- Kept `Add rate`, `5%`, and `18%` together on the lower row.
- Fixed GST result-row visibility so Different State shows IGST only and Same State shows SGST + CGST.
- Normalized Same State / Different State active and accessibility states.
- Corrected initial component tax labels to avoid showing misleading percentages before calculation.
- Preserved custom GST caret, placeholder, and quick-rate cursor behaviour.
- Added GST layout/state/caret regression coverage.
