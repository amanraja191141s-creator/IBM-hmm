# SA Calculator v98.81 — Reference Video Clean Reset Audit

## Source basis
- 720x1560 action-time recording: `Screenrecording_20261123_194055.mp4`.
- Reference measurements were taken from the supplied frames at the 720x1560 physical capture size.
- The previous v98.76-v98.80 tool-UI tail was removed and replaced by one canonical v98.81 presentation layer.

## Measured GST reference geometry
- Tool content background begins below the status bar.
- Tool header: approximately 130 physical px (104 CSS px at DPR 1.25).
- Main content horizontal boundary: approximately 25 physical px from each edge (20 CSS px).
- Original Amount card: x≈25, width≈670, height≈181 physical px (145 CSS px).
- GST mode row: approximately 50 physical px high (40 CSS px).
- GST Rate card: approximately 178–181 physical px (145 CSS px target).
- Place-of-supply row: approximately 50 physical px high (40 CSS px).
- Input/entry text baseline: approximately 42 physical px class (34 CSS px target).
- Field labels: approximately 30 physical px class (24 CSS px target).
- Result heading: approximately 35 physical px class (28 CSS px target).
- Result card: approximately 221 physical px class, with coral boundary and compact rows.
- Result rows: approximately 49 physical px class (39 CSS px target).
- Shared keypad: four rows, four columns, tall action key; dock tuned to approximately 625 physical px at the reference DPR.

## Action-time hardening
- Keypad opening/retarget scrolling uses immediate (`auto`) scrolling to avoid animation races.
- Result reveal/equals scrolling uses immediate scrolling.
- Equals closes the keypad for calculator-style tools and commits result state.
- Currency and Unit retain their swap action instead of equals semantics.
- GST keeps explicit committed-result lifecycle and nine-digit amount ceiling.
- Unit Converter keeps exactly one visible selector per From/To card.

## Validation
- 89/89 Node regression tests pass.
- JavaScript syntax checks pass.
- Root and `www/` bundle assets are synchronized byte-for-byte.
- Workflow test entry points resolve to real files.
- ZIP integrity checked with `unzip -tq`.
